package br.edu.up.as34123768.ui.navigation

interface NavigationDestination {

    val route: String

    val titleRes: Int
}
